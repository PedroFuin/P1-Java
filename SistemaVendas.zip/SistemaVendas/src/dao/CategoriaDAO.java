package dao;
import model.Categoria;


//importar conexão SQL
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class CategoriaDAO {
    
    private Connection conn; //Objeto de conexão com o banco de dados
    private  PreparedStatement pstm; // Objeto para executar consultas SQL parametrizadas
    private Statement st; // Objeto para executar consultas SQL
    private ResultSet rs; // Objeto para armazenar resultados de consultas
    private ArrayList<Categoria> lista = new ArrayList<>(); // Lista para armazenar objetos da classe Produto
    
    
    public CategoriaDAO(){
       conn = new ConnectionFactory().getConexao(); //método de conexão para inserir dados
    }

     public void inserir(Categoria categoria){
        String sql ="INSERT INTO categoria (nome) VALUES(?)";
        try {
            pstm = conn.prepareStatement(sql); //Executa linhas de comando SQL
            pstm.setString(1, categoria.getNome());
            pstm.execute();
            pstm.close();
        }catch (Exception erro){
            throw new RuntimeException("Erro 2:" +erro);
        }
    }
     
     public ArrayList<Categoria> listarTodosCategoria() {
        String sql = "SELECT * FROM categoria";
        try {
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                Categoria categoria = new Categoria();
                categoria.setIdCategoria(rs.getInt("idCategoria"));
                categoria.setNome(rs.getString("nome"));
                lista.add(categoria);
            }
        }catch (Exception erro){
                throw new RuntimeException("Erro 5:" + erro);
            }
        return lista;
    }
     

     
    

}

