package dao;

import  java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
    public Connection getConexao(){
        try{ //estabelece conexão com o bando de dados atraves da URL
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/sistema","b3","m1ndw4r3!");
        }catch (Exception erro){
            throw new RuntimeException("Erro 1:"+erro);
        }
    }



}
