package dao;
import model.Produto;
import model.Categoria;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProdutoDAO {

    private Connection conn; //Objeto de conexão com o banco de dados
    private  PreparedStatement pstm; // Objeto para executar consultas SQL parametrizadas
    private Statement st; // Objeto para executar consultas SQL
    private ResultSet rs; // Objeto para armazenar resultados de consultas
    private ArrayList<Produto> lista = new ArrayList<>(); // Lista para armazenar objetos da classe Produto


    // Construtor que estabelece uma conexão com o banco de dados.
    public ProdutoDAO(){
       conn = new ConnectionFactory().getConexao();
    }


    // Método para inserir dados na tabela de produtos
    public void inserir(Produto produto){
        String sql ="INSERT INTO produtos (descricao, preco, quantidade) VALUES(?,?,?)";
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, produto.getDescricao());
            pstm.setDouble(2,produto.getPreco());
            pstm.setInt(3,produto.getQuantidade());
            pstm.execute();
            pstm.close();
        }catch (Exception erro){
            throw new RuntimeException("Erro 2:" +erro);
        }
    }

    // Método para alterar dados na tabela de produtos
    public void alterar(Produto produto){
        String sql ="UPDATE produtos SET descricao = ?, preco = ?, quantidade = ? WHERE id = ?";
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, produto.getDescricao());
            pstm.setDouble(2,produto.getPreco());
            pstm.setInt(3,produto.getQuantidade());
            pstm.setInt(4, produto.getId());
            pstm.execute();
            pstm.close();
        }catch (Exception erro){
            throw new RuntimeException("Erro 3:" +erro);
        }
    }

    // Método para deletar dados da tabela de produtos com base no ID
    public void deletar(int valor){
        String sql ="DELETE FROM produtos WHERE id = " +valor;
        try {
            st = conn.createStatement();
            st.execute(sql);
            st.close();
        }catch (Exception erro){
            throw new RuntimeException("Erro 4:" +erro);
        }

    }

    // Método para listar todos os produtos na tabela
    public ArrayList<Produto> listarTodos() {
        String sql = "SELECT * FROM produtos";
        try {
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setQuantidade(rs.getInt("quantidade"));
                lista.add(produto);
            }
        }catch (Exception erro){
                throw new RuntimeException("Erro 5:" + erro);
            }
        return lista;
    }
    
    // Método para listar todos os produtos na tabela com base em uma descrição
    public ArrayList<Produto> listarTodosDescricao(String valor) {
        String sql = "SELECT * FROM produtos WHERE descricao LIKE '%"+valor+"%' ";
        try {
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setQuantidade(rs.getInt("quantidade"));
                lista.add(produto);
            }
        }catch (Exception erro){
                throw new RuntimeException("Erro 6:" + erro);
            }
        return lista;
    }
}
