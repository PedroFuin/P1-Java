package table;
import model.Categoria;

//Pacotes para utilização do model
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class CategoriaTableModel extends AbstractTableModel {
    
    //identificadores de coluna para criacção do Array
    public static final int COL_ID = 0;
    public static final int COL_CATEGORIA_NOME = 1;
    public ArrayList<Categoria> lista;
    
    public CategoriaTableModel(ArrayList<Categoria>l){
        lista = new ArrayList<Categoria>(1); //Criação do Array para listar
    }

    @Override
    public int getRowCount() {
        return lista.size(); //retorna o tamanho da tabela
    }

    @Override
    public int getColumnCount() {
        return 2; //quantidade de colunas que será exibido
    }
    
    @Override
    public Object getValueAt(int linhas, int colunas) {
        Categoria categoria = lista.get(linhas);
        if(colunas == COL_ID) return categoria.getIdCategoria();
        if(colunas == COL_CATEGORIA_NOME) return categoria.getNome();
        return "";
    }


    @Override
    public String getColumnName(int colunas){
            if (colunas == COL_ID) return "Código";
            if (colunas == COL_CATEGORIA_NOME) return "Nome";

            return "";
        }
}
