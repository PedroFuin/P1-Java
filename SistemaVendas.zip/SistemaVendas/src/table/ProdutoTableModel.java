package table;
import model.Produto;
import model.Categoria;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class ProdutoTableModel extends AbstractTableModel {

    public static final int COL_ID = 0;
    public static final int COL_PRODUTO_DESC = 1;
    public static final int COL_PRODUTO_PRECO = 2;
    public static final int COL_PRODUTO_QUANTIDADE = 3;
    public static final int COL_PRODUTO_CATEGORIA = 4;
    public ArrayList<Produto> lista;

    public ProdutoTableModel(ArrayList<Produto>l){
        lista = new ArrayList<Produto>(l);
    }


    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int linhas, int colunas) {
        Produto produto = lista.get(linhas);
        if(colunas == COL_ID) return produto.getId();
        if(colunas == COL_PRODUTO_DESC) return produto.getDescricao();
        if(colunas == COL_PRODUTO_PRECO) return produto.getPreco();
        if(colunas == COL_PRODUTO_QUANTIDADE) return produto.getQuantidade();
    //    if(colunas == COL_PRODUTO_CATEGORIA) return produto.getCategoria();
        return "";
    }


    @Override
    public String getColumnName(int colunas){
            if (colunas == COL_ID) return "Código";
            if (colunas == COL_PRODUTO_DESC) return "Descrição";
            if (colunas == COL_PRODUTO_PRECO) return "Preço";
            if (colunas == COL_PRODUTO_QUANTIDADE) return "Quantidade";
           // if (colunas == COL_PRODUTO_CATEGORIA) return "Categoria";
            return "";
        }
    }