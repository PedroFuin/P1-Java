package main;
import view.ProdutoView;
import view.CategoriaView;

/**
 *
 * @author Juneor
 */
public class Run {
    
    public static void main(String[]args){
       new ProdutoView().setVisible(true); //Chamar tela de produto
       // new CategoriaView().setVisible(false);
    }
}
